
package bankmanagementsystem2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.*;

public class BalanceInquiry extends JFrame implements ActionListener{
        JButton back;
        String pinno;
        int balance = 0;
    BalanceInquiry(String pinno){
        this.pinno = pinno;
         ImageIcon I1 = new ImageIcon(ClassLoader.getSystemResource("icon/atm.jpg"));
         Image I2 = I1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT);
         ImageIcon I3 = new ImageIcon(I2);
         JLabel image = new JLabel(I3);
         image.setBounds(0, 0, 900, 900);
         add(image);
         
         back = new JButton("back");
         back.setBounds(355, 520, 150, 30);
         back.setFont(new Font("Raleway", Font.BOLD,22));
         back.addActionListener(this);
         image.add(back);
         
         Conn c = new Conn();
         try{
             ResultSet rs = c.s.executeQuery("select * from bank where pin = '"+pinno+"'");
             while(rs.next()){
                 if(rs.getString("type").equals("Deposit")){
                     balance  +=Integer.parseInt(rs.getString("amount"));    
                 } else {
                      balance  -=Integer.parseInt(rs.getString("amount"));    
                 }
             }
             
         } catch(Exception e){
             System.out.println(e);
         }
         JLabel text = new JLabel("Your current account balance is "+ balance);
         text.setForeground(Color.white);
         text.setBounds(170, 300, 400, 30);
         image.add(text);
        
        
        setLayout(null);
        setVisible(true);
        setLocation(300,0);
        setSize(900,900);
      
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==back){
            setVisible(false);
            new Transactions(pinno).setVisible(true);
        }
    }
   
    public static void main(String[] args) {
       new BalanceInquiry("");
    }
    
}
