
package bankmanagementsystem2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


    public class SignUpTwo extends JFrame implements ActionListener{
    long random;
    JTextField panTextField,cnicTextField;
    JButton next;
    JRadioButton syes,sno;
    JComboBox religion,category1,income1,education1,occupation1;
    String formno;
    SignUpTwo(String formno){
        
        this.formno = formno;
        setTitle("New Account Application Form - Page 2");
       
        JLabel additionalDetails = new JLabel("Additional Details " );
        additionalDetails.setFont(new Font("Raleway", Font.BOLD, 22));
        additionalDetails.setBounds(290, 80, 400, 30);
        add(additionalDetails);
        
        JLabel name = new JLabel("Religion: ");
        name.setFont(new Font("Raleway", Font.BOLD, 20));
        name.setBounds(100, 140, 100, 30);
        add(name);
        
        String valReligion[] = {"Hindu","Muslim","Sikh","Christian","Other"};
        religion = new JComboBox(valReligion);
        religion.setBounds(300, 140, 400, 30);
        religion.setBackground(Color.white);
        add(religion);
        
        JLabel category = new JLabel("Category: ");
        category.setFont(new Font("Raleway", Font.BOLD, 20));
        category.setBounds(100, 190, 200, 30);
        add(category);
        
        String valCategory[] = {"Genrel","ST","OBC","SC","Other"};
        category1 = new JComboBox(valCategory);
        category1.setBackground(Color.white);
        category1.setBounds(300, 190, 400, 30);
        add(category1);
       
        JLabel income = new JLabel("Income: ");
        income.setFont(new Font("Raleway", Font.BOLD, 20));
        income.setBounds(100, 240, 200, 30);
        add(income);
        
        String valIncome[] = {"Null","< 1,50,000","< 2,50,000","<5,00,000","Upto 10,00,000"};
        income1 = new JComboBox(valIncome);
        income1.setBackground(Color.white);
        income1.setBounds(300,240,400,30);
        add(income1);
        
        JLabel education = new JLabel("Educational ");
        education.setFont(new Font("Raleway", Font.BOLD, 20));
        education.setBounds(100, 290, 200, 30);
        add(education);
        
        JLabel qualification = new JLabel("Qualification: ");
        qualification.setFont(new Font("Raleway", Font.BOLD, 20));
        qualification.setBounds(100, 315, 200, 30);
        add(qualification);
        
        String valEducation[] = {"Under-Graduate","Non-Graduate","Matric","Fcs/Fa","Graduate", "Other"};
        education1 = new JComboBox(valEducation);
        education1.setBackground(Color.white);
        education1.setBounds(300,315,400,30);
        add(education1);
        
        JLabel occupation = new JLabel("Occupation: ");
        occupation.setFont(new Font("Raleway", Font.BOLD, 20));
        occupation.setBounds(100, 390, 200, 30);
        add(occupation);
        
        String valOccupation[] = {"Salaried","Student","Business","Retired","Other"};
        occupation1 = new JComboBox(valOccupation);
        occupation1.setBackground(Color.white);
        occupation1.setBounds(300,390,400,30);
        add(occupation1);
        
        JLabel pan = new JLabel("Pan No: ");
        pan.setFont(new Font("Raleway", Font.BOLD, 20));
        pan.setBounds(100, 440, 200, 30);
        add(pan);
        
        panTextField = new JTextField();
        panTextField.setFont(new Font("Raleway", Font.BOLD, 14));
        panTextField.setBounds(300, 440, 400, 30);
        add(panTextField);
        
        JLabel cnic = new JLabel("CNIC No: ");
        cnic.setFont(new Font("Raleway", Font.BOLD, 20));
        cnic.setBounds(100, 490, 200, 30);
        add(cnic);
        
        cnicTextField = new JTextField();
         cnicTextField.setFont(new Font("Raleway", Font.BOLD, 14));
         cnicTextField.setBounds(300, 490, 400, 30);
        add( cnicTextField);
        
        JLabel citizen = new JLabel("Senior Citizen: ");
        citizen.setFont(new Font("Raleway", Font.BOLD, 20));
        citizen.setBounds(100, 540, 200, 30);
        add(citizen);
        
        syes = new JRadioButton("Yes");
        syes.setBounds(300, 540, 100, 30);
        syes.setBackground(Color.white);
        add(syes);
        
       sno = new JRadioButton("No");
        sno.setBounds(450, 540, 100, 30);
        sno.setBackground(Color.white);
        add(sno);
        
        ButtonGroup citizenGroup = new ButtonGroup();
        citizenGroup.add(syes);
        citizenGroup.add(sno);
      
        next = new JButton("Next");
        next.setBackground(Color.black);
        next.setForeground(Color.white);
        next.setBounds(620, 660, 80, 30);
        next.addActionListener(this);
        add(next);
        
        setLayout(null);
        getContentPane().setBackground( Color.WHITE);   
        setSize(850,800);
        setLocation(350,10);
        setVisible(true);
        
    }
    public void actionPerformed(ActionEvent ae){
        String formno = ""+ random;
        String sreligion = (String) religion.getSelectedItem();
        String category = (String) category1.getSelectedItem();
        String income = (String) income1.getSelectedItem();
        String education = (String) education1.getSelectedItem();
        String occupation = (String) occupation1.getSelectedItem();
        
        String citizen = null;
        if(syes.isSelected()){
            citizen = "Yes";
        } else if(sno.isSelected()){
            citizen = "sno";
        }
       
        String pan = panTextField.getText();
        String cnic = cnicTextField.getText();
        try{
                setVisible(false);
                new SignupThree(formno).setVisible(true);
                Conn c = new Conn();
                String query1 = "insert into signuptwo values ('"+formno+"', '"+sreligion+"', '"+category+"', '"+income+"','"+education+"', '"+occupation+"','"+pan+"','"+cnic+"','"+citizen+"')";
                c.s.executeUpdate(query1);
      
        } catch(Exception e){
            System.out.println("");
        } 
    }
    
    public static void main(String[] args) {
       new SignUpTwo("");
    } 
}


