
package bankmanagementsystem2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class Deposit extends JFrame implements ActionListener{
          JTextField amount;
          JButton deposit,back;
          String pinno;
     Deposit(String pinno){
        this.pinno = pinno;
         ImageIcon I1 = new ImageIcon(ClassLoader.getSystemResource("icon/atm.jpg"));
         Image I2 = I1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT);
         ImageIcon I3 = new ImageIcon(I2);
         JLabel image = new JLabel(I3);
         image.setBounds(0, 0, 900, 900);
         add(image);
         
         JLabel text = new JLabel("Enter the amount you want to deposit: ");
         text.setBounds(170, 300, 400, 20);
         text.setFont(new Font("System", Font.BOLD, 16));
         text.setForeground(Color.white);
         image.add(text);
         
         amount = new JTextField();
         amount.setFont(new Font("Raleway", Font.BOLD,22));
         amount.setBounds(170, 350, 320, 25);
         image.add(amount);
         
         deposit = new JButton("Deposit");
         deposit.setFont(new Font("Raleway", Font.BOLD, 22));
         deposit.setBounds(355, 485, 150, 30);
         deposit.addActionListener(this);
         image.add(deposit);
         
         back = new JButton("Back");
         back.setFont(new Font("Raleway", Font.BOLD, 22));
         back.setBounds(355, 520, 150, 30);
         back.addActionListener(this);
         image.add(back);
         
         setLayout(null);
         setLocation(300,0);
         setSize(900,900);
         setVisible(true);
     }
     public void actionPerformed(ActionEvent ae){
         if(ae.getSource()==deposit){
             String number = amount.getText();
             Date date = new Date();
             if(number.equals("")){
                 JOptionPane.showMessageDialog(null, "Please enter the amount");
             } else {
                 try{
                 Conn conn = new Conn();
                 String query = "insert into bank values('"+pinno+"','"+date+"','Deposit','"+number+"')";
                 conn.s.executeUpdate(query);
                 JOptionPane.showMessageDialog(null, "Transaction Successfull");
                 setVisible(false);
                 new Transactions(pinno).setVisible(true);
             } catch(Exception e){
                 System.out.println(e);
             }
         }
         }else if(ae.getSource()==back){
             setVisible(false);
             new Transactions(pinno).setVisible(true);
         }
     }
    
    public static void main(String[] args) {
      new Deposit("");
    }
    
}
