
package bankmanagementsystem2;
import java.sql.*;

public class Conn {
    
    Connection c;
    Statement s;
         
    public Conn(){
        try{
          
            c = DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem", "root", "a1q2s3a4");
            s = c.createStatement();
        } catch(Exception e){
            System.out.println("");
        }
    
               
     }
      
    }
    

